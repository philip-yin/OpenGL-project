In this assignment, I have successfully implemented by myself:
1. Camera and eye ray generation
2. Ray surface intersections
3. Transformations
4. Shadow Rays

and partially implemented
5. Shading---where ambient and emission works fine, but diffuse and specular
are off. I believe it is a minor issue around norm vector at intersection but
I failed to debug it out.

and failed to implement
6. recursive ray tracing

since I am working alone, I do not need to implement acceleration.
 